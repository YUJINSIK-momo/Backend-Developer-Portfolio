# CLAUDE.md

이 파일은 Claude Code가 항상 자동으로 읽는 프로젝트 헌법입니다.
**짧게 유지하세요. 100~200줄 이내.** 세부 내용은 `docs/` 하위 파일에 분리합니다.

---

## 프로젝트 개요

(한두 문장으로 이 프로젝트가 무엇인지 적습니다.)

예) 이 프로젝트는 ___ 사용자가 ___ 문제를 해결하도록 돕는 ___ 서비스이다.

---

## 기술 스택

- 언어:
- 프레임워크:
- DB:
- 배포:

---

## CRITICAL 규칙 (3개 이내)

절대 어기면 안 되는 규칙만 적습니다. 많이 적으면 지켜지지 않습니다.

1. `any` 타입 금지 — TypeScript 안전성 우선
2. 빌드(`npm run build`) 통과 전에는 커밋 금지
3. 한 번에 한 작업만 — 페이지 추가 + 리팩토링 + 버그 수정을 섞지 않는다

---

## 개발 프로세스

1. **시작 전**: `phases/` 폴더에서 현재 phase 파일 확인
2. **구현**: 한 페이지/한 컴포넌트 단위로
3. **검증**: `npm run lint && npm run build`
4. **커밋**: 한글 메시지 + prefix
   - `feat:` 기능 추가
   - `fix:` 버그 수정
   - `docs:` 문서 수정
   - `refactor:` 코드 개선
   - `chore:` 설정 변경

---

## 명령어

| 명령어 | 설명 |
|--------|------|
| `npm run dev` | 개발 서버 |
| `npm run lint` | 린트 |
| `npm run build` | 빌드 |
| `npm test` | 테스트 |

---

## 참조 문서

세부 내용은 다음을 참조 (필요할 때 명시적으로 읽기):

- `docs/PRD.md` — 무엇을 만드는지
- `docs/ARCHITECTURE.md` — 어떻게 만드는지
- `docs/ADR.md` — 왜 그렇게 결정했는지
- `docs/UI_GUIDE.md` — 어떻게 보여야 하는지
- `phases/` — 단계별 작업 명세

---

## 완료의 정의

작업이 "완료"되려면 **`npm run verify`** 가 통과해야 한다.
이 명령은 `scripts/verify.sh`(Windows는 `scripts/verify.ps1`)를 실행하며 다음을 순차 검증한다:

1. `npm run lint` 통과 (warnings 0건)
2. `npm run build` 통과
3. `npm test --if-present` 통과

추가 시각 점검:

- [ ] 모바일 레이아웃 깨짐 없음
- [ ] 영향받는 기존 페이지가 여전히 동작

> **TIP**: `package.json`의 `scripts`에 `"verify": "sh scripts/verify.sh"` 한 줄을 추가하세요.
> 그 다음부터 Claude의 Stop hook이 매 작업 종료 시 자동으로 verify를 호출합니다.
