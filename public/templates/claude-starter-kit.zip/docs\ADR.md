# Architecture Decision Records (ADR)

> **목적**: 6개월 뒤 "왜 이렇게 했지?"에 답하는 기록.
> 큰 결정이 생길 때마다 ADR-NN 형식으로 추가.

---

## ADR-001: 상태관리 라이브러리 미사용

- **결정**: useState + Context만 사용
- **이유**: 정적 사이트, 전역 상태가 거의 없음. Zustand/Redux는 오버엔지니어링.
- **대안**: Zustand, Redux Toolkit, Jotai
- **트레이드오프**: 상태가 복잡해지면 재검토. 페이지 수 30개 또는 전역 상태 5개 이상 시.
- **결정일**: 2026-01-15

---

## ADR-002: Tailwind CSS 채택

- **결정**: 유틸리티 CSS 프레임워크로 Tailwind 사용
- **이유**: 디자인 토큰을 코드와 함께 관리. 컴포넌트 라이브러리 없이도 일관성 유지 가능.
- **대안**: styled-components, CSS Modules, vanilla CSS
- **트레이드오프**: HTML이 길어진다. 하지만 디자인 일관성 이득이 더 큼.
- **결정일**: 2026-01-15

---

## ADR-003: 라우팅 라이브러리

- **결정**: react-router-dom
- **이유**: SPA 라우팅 표준. 생태계 안정적.
- **대안**: TanStack Router, Next.js
- **트레이드오프**: Next.js로 가면 SSR이 가능하지만 GitHub Pages 정적 배포 충돌
- **결정일**: 2026-01-15

---

## 템플릿

새 ADR을 추가할 때 이 형식을 복사:

```
## ADR-NNN: 제목

- **결정**:
- **이유**:
- **대안**:
- **트레이드오프**:
- **결정일**: YYYY-MM-DD
```
