# Claude Code Starter Kit

Claude Code를 활용한 프로젝트의 시작점입니다.
이 키트를 본인 프로젝트 루트에 풀면 바로 사용할 수 있습니다.

---

## 폴더 구조

```
.
├── CLAUDE.md              ← 프로젝트 헌법 (항상 자동 로드)
├── .gitignore
├── .claude/
│   ├── settings.json      ← 권한·hooks 설정 (팀 공유)
│   ├── commands/
│   │   ├── review.md      ← /review 슬래시 명령
│   │   └── deploy.md      ← /deploy 슬래시 명령
│   └── agents/
│       └── reviewer.md    ← 코드 리뷰 서브에이전트
├── docs/
│   ├── PRD.md             ← 뭘 만드는지 (What)
│   ├── ARCHITECTURE.md    ← 어떻게 만드는지 (How)
│   ├── ADR.md             ← 왜 그렇게 결정했는지 (Why)
│   └── UI_GUIDE.md        ← 어떻게 보여야 하는지 (Look)
└── phases/
    └── phase-01-setup.md  ← 현재 작업 명세
```

---

## 사용 방법

### 1. 압축 풀기

```bash
unzip claude-starter-kit.zip
cp -r claude-starter-kit/. /path/to/your-project/
```

또는 본인 프로젝트 루트에서 직접 풀어도 됩니다.

### 2. 핵심 4파일 채우기 (15분)

순서대로 본인 프로젝트에 맞게 수정합니다.

1. `CLAUDE.md` — 기술 스택, CRITICAL 규칙 3개
2. `docs/PRD.md` — 사용자·핵심 기능·성공 기준
3. `docs/ARCHITECTURE.md` — 폴더 구조·데이터 흐름
4. `docs/UI_GUIDE.md` — 색상 토큰·간격

ADR.md는 큰 결정이 생길 때마다 추가.

### 3. Claude Code 실행

```bash
claude
```

첫 메시지로 다음과 같이 입력:

```
phases/phase-01-setup.md 확인하고 미완료 항목 처리해줘
```

### 4. 슬래시 명령 사용

- `/review` — 현재 변경사항 코드 리뷰
- `/deploy` — 빌드 → 커밋 → 푸쉬 자동화

---

## 더 알아보기

- 기초 가이드: https://yujinsik-momo.github.io/Backend-Developer-Portfolio/claude-guide
- Advanced (하네스 엔지니어링): https://yujinsik-momo.github.io/Backend-Developer-Portfolio/claude-advanced
