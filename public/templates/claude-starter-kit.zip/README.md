# Claude Code Starter Kit

Claude Code를 활용한 프로젝트의 시작점입니다.
이 키트를 본인 프로젝트 루트에 풀면 바로 사용할 수 있습니다.

---

## 폴더 구조

```
.
├── CLAUDE.md              ← 프로젝트 헌법 (항상 자동 로드)
├── .gitignore
├── .claude/
│   ├── settings.json      ← 권한·hooks 설정 (팀 공유)
│   ├── commands/
│   │   ├── review.md      ← /review 슬래시 명령
│   │   ├── deploy.md      ← /deploy 슬래시 명령
│   │   ├── new-project.md ← /new-project (빈 프로젝트를 키트로 구축)
│   │   ├── apply-kit.md   ← /apply-kit (기존 코드에 키트 적용)
│   │   └── phase.md       ← /phase (목표를 phase 문서로 만들고 진행)
│   └── agents/
│       └── reviewer.md    ← 코드 리뷰 서브에이전트
├── .agents/
│   └── skills/            ← 외부 스킬 번들 (6종)
│       ├── andrej-karpathy-skills
│       ├── find-skills
│       ├── frontend-design          (Apache 2.0)
│       ├── karpathy-guidelines
│       ├── vercel-react-best-practices
│       └── web-design-guidelines
├── docs/
│   ├── PRD.md             ← 뭘 만드는지 (What)
│   ├── ARCHITECTURE.md    ← 어떻게 만드는지 (How)
│   ├── ADR.md             ← 왜 그렇게 결정했는지 (Why)
│   └── UI_GUIDE.md        ← 어떻게 보여야 하는지 (Look)
├── scripts/
│   ├── verify.sh          ← lint + build + test 묶음 (POSIX)
│   └── verify.ps1         ← 동일 (Windows PowerShell)
├── .github/
│   └── workflows/
│       └── verify.yml     ← GitHub Actions CI (push/PR 자동 검증)
└── phases/
    └── phase-01-setup.md  ← 현재 작업 명세
```

### `.agents/skills/`에 대해

Claude Code가 참조할 수 있는 외부 스킬 모음입니다.
각 스킬 폴더 안의 `SKILL.md` 또는 `README.md`에 해당 스킬의 적용 가이드가 들어 있습니다.
필요한 스킬만 골라 쓰거나, 사용하지 않을 스킬 폴더는 삭제해도 무방합니다.

---

## 사용 방법

### 1. 압축 풀기

```bash
unzip claude-starter-kit.zip
cp -r claude-starter-kit/. /path/to/your-project/
```

또는 본인 프로젝트 루트에서 직접 풀어도 됩니다.

### 2. 핵심 4파일 채우기 (15분)

순서대로 본인 프로젝트에 맞게 수정합니다.

1. `CLAUDE.md` — 기술 스택, CRITICAL 규칙 3개
2. `docs/PRD.md` — 사용자·핵심 기능·성공 기준
3. `docs/ARCHITECTURE.md` — 폴더 구조·데이터 흐름
4. `docs/UI_GUIDE.md` — 색상 토큰·간격

ADR.md는 큰 결정이 생길 때마다 추가.

### 3. Claude Code 실행

```bash
claude
```

첫 메시지로 다음과 같이 입력:

```
phases/phase-01-setup.md 확인하고 미완료 항목 처리해줘
```

### 4. 슬래시 명령 사용

기본 작업용:

- `/review` — 현재 변경사항 코드 리뷰
- `/deploy` — 빌드 → 커밋 → 푸쉬 자동화

프로젝트 부트스트랩용:

- `/new-project <컨셉/스택/핵심기능>` — 빈 프로젝트를 이 키트 구조로 처음부터 구축
- `/apply-kit [컨셉] [스택]` — 기존 코드를 분석한 뒤 키트를 입히고 정리·개선
- `/phase <이번에 할 일>` — 목표를 `phases/phase-0N-*.md` 문서로 만들고 그 체크리스트대로 진행

### 5. 검증 자동화 활성화 (중요)

본인 프로젝트의 `package.json`에 한 줄 추가:

```json
{
  "scripts": {
    "verify": "sh scripts/verify.sh"
  }
}
```

Windows에서는:

```json
{
  "scripts": {
    "verify": "powershell -ExecutionPolicy Bypass -File scripts/verify.ps1"
  }
}
```

이것만 추가하면:

- Claude의 **Stop hook**이 작업 종료 시 자동으로 `npm run verify` 실행
- GitHub Actions(`.github/workflows/verify.yml`)가 push/PR마다 동일 검증 실행
- 두 단계의 검증으로 "다 됐어요"가 실제로 통과한 작업만 의미하게 됨

---

## 더 알아보기

- 기초 가이드: https://yujinsik-momo.github.io/Backend-Developer-Portfolio/claude-guide
- Advanced (하네스 엔지니어링): https://yujinsik-momo.github.io/Backend-Developer-Portfolio/claude-advanced
