---
description: harness-legacy-scan 리포트 기반 low-risk 하네스 개선만 적용하는 Dynamic Workflow
argument-hint: [적용할 finding ID 또는 범위] (선택)
---

`ultracode`로 `harness-legacy-scan` 리포트를 바탕으로 **low-risk 하네스 개선만** 적용하는
Dynamic Workflow를 설계하고 실행해줘.
워크플로우 이름: `harness-diet`

적용 범위 지정(있으면): $ARGUMENTS

## 목표

하네스를 더 짧고, 더 명확하고, 필요한 순간에만 나타나는 구조로 정리한다.

## 적용 전 게이트 (Freshness Gate — 반드시 먼저)

리포트는 과거의 스냅샷이다. 그 사이 파일이 바뀌었을 수 있으므로, 적용 전에 검증한다.

1. **신선도 대조** — 각 finding이 가리키는 경로·라인앵커·내용이 현재 워킹트리와 여전히 일치하는지 결정론적으로 확인한다. 경로 부재·내용 불일치(scan 이후 사람이 손댐)가 감지되면 그 항목은 적용하지 않고 "stale → 재-scan 필요" 목록으로 **격리**한다. 조용히 건너뛰지 않는다.
2. **위험도 독립 재확인** — 리포트의 자가판정에 의존하지 말고 각 항목의 위험도를 다시 판정한다. "low-risk"가 불확실하면 적용하지 말고 "수동 승인 필요"로 남긴다.
3. **참조 정합성** — MOVE/DELETE 대상이 다른 설정·문서에서 참조되면(Dangling-Reference) 적용을 보류하고 사람에게 보고한다.

## 허용되는 변경 (택소노미 처분별)

1. **SHRINK** — `CLAUDE.md`에서 중복되거나 너무 일반적인 지침을 줄인다.
2. **MOVE** — 특정 작업에만 필요한 절차를 `CLAUDE.md` → `.claude/skills/` 아래 Skill로 옮긴다.
3. **SPLIT** — 너무 긴 `SKILL.md`를 `SKILL.md` + `reference.md` + `examples.md`로 나눈다.
4. **CONVERT** — Skill description을 좁히고, 상시 규칙을 조건부 규칙으로 바꾼다.
5. **GUARD** — 자동 호출 범위가 너무 넓은 Skill에 "사용하지 말아야 할 때" 섹션을 추가한다.
6. **MERGE** — 중복된 규칙을 하나로 통합한다.
7. **DEPRECATE** — 즉시 제거 대신 일몰(예정) 표시만 남기고 단계적으로 폐기한다.
8. **DELETE** — 삭제 후보는 영구 삭제하지 말고 `.claude/archive/harness-diet-YYYY-MM-DD/` 아래로 옮긴다.
9. 변경 이유는 파일 주석으로 흩뜨리지 말고 최종 요약에 정리한다.

## 금지되는 변경

- 파일 영구 삭제
- hooks 수정 / MCP 설정 수정 / allowed-tools 권한 확대
- 애플리케이션 코드 수정
- 테스트·빌드·배포 명령 임의 실행
- Freshness Gate를 통과하지 못한 항목(stale·고위험·참조 충돌) 적용

## 개선 원칙

- 전역 지침은 짧고 안정적인 프로젝트 원칙만 담는다.
- 반복 절차는 Skill로, 긴 설명·예시·체크리스트는 `reference.md` / `examples.md`로 분리한다.
- 작은 작업을 느리게 만드는 규칙은 조건부 규칙으로 바꾼다.
- 안전장치는 함부로 삭제하지 않는다.

## 작업 후 보고

1. 변경한 파일 목록 (각 변경 ↔ 출처 finding ID 매핑)
2. 파일별 변경 이유
3. Before / After 요약
4. diff 요약
5. Freshness Gate에서 격리된 stale·고위험·참조충돌 항목 목록
6. Claude의 행동이 어떻게 달라지는지
7. 아직 사람이 승인해야 하는 high-risk 항목
8. 새 하네스 검증용 smoke-test 프롬프트 5개

> 변경 후에는 `git diff`로 확인하고, 위 smoke-test 프롬프트로 회귀를 점검한다.
> 삭제 대신 `.claude/archive/`로 옮겼으므로, 문제가 생기면 되돌릴 수 있다.
