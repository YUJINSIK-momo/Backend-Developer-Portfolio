---
description: AI 코딩 하네스를 읽기 전용으로 감사하는 Dynamic Workflow 설계·실행 (분석 리포트만)
argument-hint: [감사 범위] (선택, 없으면 전체 하네스)
---

`ultracode`로 내 AI 코딩 하네스를 **읽기 전용으로 감사**하는 Dynamic Workflow를 설계하고 실행해줘.
워크플로우 이름: `harness-legacy-scan`

추가 범위 지정(있으면): $ARGUMENTS

## 목표

하네스에 남아 있는 낡은 규칙, 중복 지시, 과도한 전역 컨텍스트, 너무 넓은 Skill,
불필요한 Hook/MCP, 제품 기본 기능과 중복되는 설정, 서로 모순되는 지시를 찾아낸다.

## 감사 범위

- `CLAUDE.md`, `AGENTS.md`
- `.claude/skills/**`, `.claude/commands/**`, `.claude/workflows/**`, `.claude/agents/**`
- `.claude/settings.json`, `.claude/settings.local.json`
- `.cursor/rules/**`
- MCP 설정 파일(`.mcp.json` 등, 있으면)
- hooks 설정(있으면)

## 절대 제한 (이번 단계)

- 파일을 수정·삭제하지 않는다.
- hooks·MCP 설정·allowed-tools 권한을 바꾸지 않는다.
- **분석 리포트만** 작성한다.

## 감사 원칙

- 좋은 하네스는 반복되는 실제 실수를 막는다. 과거 습관을 보존하려고 존재하지 않는다.
- 하네스는 더 붙이는 게 아니라 필요한 순간에만 나타나야 한다.
- 이번 목표는 규칙을 추가하는 게 아니라, 낡은 규칙을 찾아 줄일 후보를 분류하는 것.

## 관점별 에이전트로 분담

> 각 에이전트는 담당 표면이 없으면 "대상 없음"으로 빠르게 종료해 비용을 아낀다.
> 한 항목은 1차 소유 에이전트만 보고하도록 dedup해 중복 리포트를 막는다.

**사전 단계**

1. **Inventory** — 하네스 관련 파일·설정을 목록화하고, 어디서도 쓰이지 않는 잔재를 표시한다. 나머지 에이전트가 이 산출물을 공유한다.

**컨텍스트 비용**

2. **Global Context Tax** — 모든 세션에 상시 로드되는 지침(CLAUDE.md / AGENTS.md / Cursor Rules)의 always-on 비용을 실측(바이트·토큰)하고 평가
3. **Skill Quality** — 호출될 때만 비용을 내는 Skill: 지금도 필요한가, description이 너무 넓은가, SKILL.md가 너무 긴가
4. **Product Overlap** — 이제 Claude Code / Codex / Cursor 제품 기본 기능과 중복되는 규칙

**권한·안전 (표면별 분리)**

5. **Permission Scope** — `allowed-tools` 허용 범위가 실제 작업보다 넓은가 (권한 폭만)
6. **Hook Firing & Frequency** — hooks의 *발화 행동*: 과빈도(매 Edit/Stop마다 무차별 실행), 조용한 실패(`|| echo`·`--silent`로 게이트 무력화), 중복 실행, matcher 범위 적정성
7. **MCP Surface & Credential** — 연결된 MCP 서버·툴 카탈로그의 표면: 미사용 서버, 과도한 툴 노출폭, 외부 egress·자격증명 scope가 실사용보다 넓은가

**정합성**

8. **Cross-Item Conflict** — 항목들을 쌍대 비교해 *상반된 지시*를 찾는다 (예: settings가 사전 허용한 행위를 지침·명령이 금지). 충돌마다 우선순위(precedence) 규칙 권고
9. **Dangling-Reference** — MOVE / SPLIT / DELETE 후보가 다른 CLAUDE.md·SKILL.md·plugin.json·settings·문서에서 경로·이름으로 참조되는지 grep해, 옮기거나 지우면 깨질 참조를 사전 목록화

**판단 (분류 + 양방향 반박)**

10. **Refactor Planner** — 각 항목을 KEEP / SHRINK / MOVE / SPLIT / CONVERT / MERGE / DEPRECATE / GUARD / DELETE로 분류
11. **Adversarial Reviewer** — *양방향* 반박: 줄이면 위험해질 항목(과다삭감)과 아무것도 못 줄인 항목(과소삭감)을 모두 검토하고, Dangling-Reference 결과로 정합성 회귀를 교차확인

## 분류 택소노미

| 처분 | 의미 |
|------|------|
| KEEP | 그대로 유지 |
| SHRINK | 더 짧게 |
| MOVE | 더 맞는 위치로 (전역 → Skill 등) |
| SPLIT | SKILL.md → reference.md / examples.md로 분리 |
| CONVERT | 상시 규칙 → 조건부 규칙 |
| MERGE | 중복 규칙을 하나로 통합 |
| DEPRECATE | 즉시 제거가 아니라 일몰 표시 후 단계적 폐기 |
| GUARD | 삭제 대신 "사용하지 말아야 할 때" 조건·가드 섹션으로 안전화 |
| DELETE | archive로 이동 (diet 단계에서) |

## 발견 항목 형식

- **ID** (안정적 식별자 — diet가 어떤 변경이 어떤 finding에서 나왔는지 역추적)
- 경로
- 현재 목적
- 발견한 문제
- 근거
- 추천 조치 (위 택소노미 중 하나)
- 옮긴다면 추천 위치
- 변경 시 위험도
- 신뢰도
- `/harness-diet`에서 자동 처리 가능 여부

## 마지막 섹션 (필수)

1. 전체 요약
2. 유지할 항목
3. 줄일 항목
4. 전역 지침 → Skill로 옮길 항목
5. Skill → `reference.md` / `examples.md`로 분리할 항목
6. 삭제 후보
7. 사람이 직접 승인해야 하는 위험한 변경
8. `/harness-diet`로 넘겨도 되는 low-risk 변경 목록 (finding ID 기준)
9. `/harness-diet` 실행용 추천 프롬프트

> 진행상황은 `/workflows`로 보고, 끝나면 리포트가 세션에 남는다.
> 납득되는 low-risk 항목만 골라 `/harness-diet`에 넘긴다.
